﻿//using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;
using System;
namespace Login.Models
{
	public class User
	{
        public int userId { get; set; }

        [Required]
		[Display(Name = "User Name")]
		public string username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }

        public string email { get; set; }

        public string phonenumber { get; set; }

        public string dob { get; set; }

        public string firstname { get; set; }

        public string lastname { get; set; }
    }
}

