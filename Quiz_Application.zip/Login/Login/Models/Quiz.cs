﻿//using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;
using System;

namespace Login.Models
{
	public class Quiz
	{
        public int quizId { get; set; }
        public int userId { get; set; }
        public int categoryId { get; set; }
    }
}

