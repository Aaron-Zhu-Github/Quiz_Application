﻿//using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;
using System;

namespace Login.Models
{
	public class Question
	{
        public int questionId { get; set; }
        public string content { get; set; }
        public int categoryId { get; set; }
    }
}

