﻿//using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;
using System;

namespace Login.Models
{
	public class Category
	{
        public int categoryId { get; set; }
        public string categoryName { get; set; }
    }
}

