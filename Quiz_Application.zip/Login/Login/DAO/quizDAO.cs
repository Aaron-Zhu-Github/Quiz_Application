﻿using System;
using System.Data;
using System.Data.SqlClient;
using Login.Models;

namespace Login.DAO
{
	public class quizDAO
	{
        private readonly IConfiguration _configuration;
        private readonly string _easyQuestionQuery = "SELECT Content FROM question WHERE category_Id = 1";
        private readonly string _choiceQuery = "SELECT * FROM choice WHERE Question_ID = @questionId";

        public quizDAO(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<Question> GetQuestionByCategory()
        {
            List<Question> questions = new List<Question>();
            using (var conn = new SqlConnection(_configuration.GetConnectionString("MyConn")))
            {
                conn.Open();
                var cmd = new SqlCommand(_easyQuestionQuery, conn);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        questions.Add(
                            new Question()
                            {
                                content = Convert.ToString(reader["Content"])
                            }
                            );
                    }
                }
            }

            return questions;
        }


        public Choice GetChoiceByQuestion(Choice choice)
        {
            Choice choice1 = choice;
            using (var conn = new SqlConnection(_configuration.GetConnectionString("MyConn")))
            {
                conn.Open();
                var cmd = new SqlCommand(_choiceQuery, conn);
                cmd.Parameters.AddWithValue("@questionId", choice.questionId);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        choice1.value = Convert.ToString(reader["Value"]);
                        choice1.isCorrect = Convert.ToBoolean(reader["isCorrect"]);
                        choice1.questionId = Convert.ToInt32(reader["Question_ID"]);
                    }
                }
            }

            return choice1;
        }
    }
}

