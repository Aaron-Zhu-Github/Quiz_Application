﻿using System;
using System.Data;
using System.Data.SqlClient;
using Login.Models;

namespace Login.DAO
{
	public class userDAO
	{
        private readonly IConfiguration _configuration;
        private readonly string _insertQuery = "INSERT INTO users VALUES (@username, @password, @email, @phonenumber, @dob, @firstname, @lastname)";
        private readonly string _finduserquery = "SELECT * FROM users WHERE Username = @username AND Passwords = @password";

        public userDAO(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // find user in database
        public User finduser(User user)
        {
            User user1 = user;
            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("MyConn")))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(_finduserquery, conn);
                cmd.Parameters.AddWithValue("@username", user.username);
                cmd.Parameters.AddWithValue("@password", user.password);
                using (var reader = cmd.ExecuteReader())
                {

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            user1.userId = Convert.ToInt32(reader["User_ID"]);
                            user1.username = Convert.ToString(reader["Username"]);
                            user1.email = Convert.ToString(reader["Email"]);
                            user1.phonenumber = Convert.ToString(reader["Phone_Num"]);
                            user1.dob = Convert.ToString(reader["DOB"]);
                            user1.firstname = Convert.ToString(reader["First_Name"]);
                            user1.lastname = Convert.ToString(reader["Last_Name"]);
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
                

            }
            return user1;
        }
        //register
        public int AddUser(User User)
        {
            int rowAffected;
            using (var conn = new SqlConnection(_configuration.GetConnectionString("MyConn")))
            {
                conn.Open();
                var cmd = new SqlCommand(_insertQuery, conn);
                cmd.Parameters.AddWithValue("@username", User.username);
                cmd.Parameters.AddWithValue("@password", User.password);
                cmd.Parameters.AddWithValue("@email", User.email);
                cmd.Parameters.AddWithValue("@phonenumber", User.phonenumber);
                cmd.Parameters.AddWithValue("@dob", User.dob);
                cmd.Parameters.AddWithValue("@firstname", User.firstname);
                cmd.Parameters.AddWithValue("@lastname", User.lastname);
                rowAffected = cmd.ExecuteNonQuery();
            }
            return rowAffected;
        }
     }
 }


