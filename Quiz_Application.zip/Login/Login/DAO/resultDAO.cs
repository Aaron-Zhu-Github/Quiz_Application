﻿using System;
using System.Data;
using System.Data.SqlClient;
using Login.Models;

namespace Login.DAO
{
    public class resultDAO
	{
        private readonly IConfiguration _configuration;
        public resultDAO(IConfiguration configuration)
        {
            _configuration = configuration;
        }
    }
}

