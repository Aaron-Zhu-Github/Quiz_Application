﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;
using System;
using Login.DAO;
using Login.Models;

namespace Login.Controllers
{
	public class UserController : Controller
    {
        private readonly userDAO _userDao;
        public UserController(userDAO userDao)
        {
            _userDao = userDao;
        }

        // Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
           
        }

        [HttpPost]
        public async Task<IActionResult> Login(User UserInfo)
        {
            //if (!ModelState.IsValid) return View();
            var model = _userDao.finduser(UserInfo);

            //verify the user credential
            if (model != null)
            {
                //if the user provide correct username and pwd
                //create the security context
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, model.userId.ToString()),
                    new Claim(ClaimTypes.Name, model.username),
                    new Claim(ClaimTypes.Email, model.email),
                    new Claim(ClaimTypes.HomePhone, model.phonenumber),
                    new Claim(ClaimTypes.GivenName, model.firstname),
                    new Claim(ClaimTypes.Surname, model.lastname),
                    //new Claim("Department", "HR") //cannot access private page for now
                };

                        var identity = new ClaimsIdentity(claims, "MyCookie");
                ClaimsPrincipal principal = new ClaimsPrincipal(identity);

                //Use the SignIn method in HttpContext, for now please follow the syntax
                await HttpContext.SignInAsync("MyCookie", principal);
                return Redirect("/Home/Index");
            }
            
            return View();
        }

        // Logout
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync("MyCookie");
            return Redirect("/User/Login");
        }

        // Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
            _userDao.AddUser(user);
            return RedirectToAction("Login");
        }
    }
}

