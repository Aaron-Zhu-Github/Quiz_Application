﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;
using System;
using Login.DAO;
using Login.Models;

namespace Login.Controllers
{
	public class ResultController : Controller
	{
        private readonly resultDAO _resultDao;
        public ResultController(resultDAO resultDao)
        {
            _resultDao = resultDao;
        }


        [HttpGet]
        public IActionResult UserResult()
        {
            return View();
        }

    }
}

