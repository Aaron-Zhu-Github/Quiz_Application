﻿using System;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;
using Login.DAO;
using Login.Models;

namespace Login.Controllers
{
	public class QuizController : Controller
	{
        private readonly quizDAO _quizDao;
        public QuizController(quizDAO quizDao)
		{
			_quizDao = quizDao;
		}

        [HttpGet]
        public IActionResult ShowQuestion()
        {
            List<Question> questions = _quizDao.GetQuestionByCategory();
            return View(questions);

        }

       
       
    }
}

